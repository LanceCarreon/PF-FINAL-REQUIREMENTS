
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.*;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.io.*;
import java.io.FileFilter;

import java.io.FileOutputStream;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;

public class User_Information extends javax.swing.JFrame {

    /**
     * Creates new form User_Information
     */
    public User_Information() {
        initComponents();
        Connect();
        LoadUserNO();
        Fetch();
    }

    Connection con;
    PreparedStatement pst;
    ResultSet rs;

    public void Connect(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/lance_db","root","");
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(User_Information.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(User_Information.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void LoadUserNO(){
        try {
            pst = con.prepareStatement("SELECT id FROM user_info");
            rs = pst.executeQuery();
            comboSearch.removeAllItems();
            while(rs.next()){
            comboSearch.addItem(rs.getString(1));
            }
        } catch (SQLException ex) {
            Logger.getLogger(User_Information.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void Fetch(){
        try {
            int q;
            pst = con.prepareStatement("SELECT * FROM user_info");
            rs = pst.executeQuery();
            ResultSetMetaData rss = rs.getMetaData();
            q = rss.getColumnCount();

            DefaultTableModel df = (DefaultTableModel) jTable1.getModel();
            df.setRowCount(0);
            while (rs.next()) {
                Vector v2 = new Vector();
                for (int a = 1; a <= q; a++) {
                    v2.add(rs.getString("id"));
                    v2.add(rs.getString("FName"));
                    v2.add(rs.getString("MName"));
                    v2.add(rs.getString("LName"));
                    v2.add(rs.getString("Address"));
                    v2.add(rs.getString("Email"));
                }
                df.addRow(v2);
            }
        } catch (SQLException ex) {
            Logger.getLogger(User_Information.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        FName = new javax.swing.JLabel();
        MName = new javax.swing.JLabel();
        LName = new javax.swing.JLabel();
        Address = new javax.swing.JLabel();
        Email = new javax.swing.JLabel();
        txtFName = new javax.swing.JTextField();
        txtMName = new javax.swing.JTextField();
        txtLName = new javax.swing.JTextField();
        txtAddress = new javax.swing.JTextField();
        txtEmail = new javax.swing.JTextField();
        UserID = new javax.swing.JLabel();
        comboSearch = new javax.swing.JComboBox<>();
        btnADD = new javax.swing.JButton();
        btnUPDATE = new javax.swing.JButton();
        btnDELETE = new javax.swing.JButton();
        btnEXPORT = new javax.swing.JButton();
        btnSEARCH = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        FORM = new javax.swing.JLabel();
        btnPDF = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        FName.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        FName.setText("First Name :");

        MName.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        MName.setText("Middle Name :");

        LName.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        LName.setText("Last Name :");

        Address.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        Address.setText("Address :");

        Email.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        Email.setText("Email :");

        txtFName.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N

        txtMName.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N

        txtLName.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N

        txtAddress.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N

        txtEmail.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N

        UserID.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        UserID.setText("User ID :");

        comboSearch.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        btnADD.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        btnADD.setText("ADD");
        btnADD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnADDActionPerformed(evt);
            }
        });

        btnUPDATE.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        btnUPDATE.setText("UPDATE");
        btnUPDATE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUPDATEActionPerformed(evt);
            }
        });

        btnDELETE.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        btnDELETE.setText("DELETE");
        btnDELETE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDELETEActionPerformed(evt);
            }
        });

        btnEXPORT.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        btnEXPORT.setText("Export to CSV");
        btnEXPORT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEXPORTActionPerformed(evt);
            }
        });

        btnSEARCH.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        btnSEARCH.setText("SEARCH");
        btnSEARCH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSEARCHActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID", "First Name", "Middle Name", "Last Name", "Address", "Email"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        FORM.setFont(new java.awt.Font("Arial", 1, 36)); // NOI18N
        FORM.setText("USER INFORMATION FORM");

        btnPDF.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        btnPDF.setText("Export to PDF");
        btnPDF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPDFActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnADD)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnUPDATE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnDELETE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnEXPORT)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnPDF))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(MName, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(FName, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(LName, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(Address, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(Email, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(txtMName, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(174, 174, 174)
                                        .addComponent(btnSEARCH))
                                    .addComponent(txtLName, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtAddress, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(txtFName, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(92, 92, 92)
                                        .addComponent(UserID)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(comboSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 516, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(19, 19, 19)
                                .addComponent(FORM)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(34, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(FORM)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(FName)
                    .addComponent(txtFName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(UserID)
                    .addComponent(comboSearch, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(MName)
                    .addComponent(txtMName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSEARCH))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LName)
                    .addComponent(txtLName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Address)
                    .addComponent(txtAddress, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Email)
                    .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnADD)
                    .addComponent(btnUPDATE)
                    .addComponent(btnDELETE)
                    .addComponent(btnEXPORT)
                    .addComponent(btnPDF))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 304, Short.MAX_VALUE))
                .addContainerGap(41, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnUPDATEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUPDATEActionPerformed
        if(txtFName.getText().isEmpty()){
            JOptionPane.showMessageDialog(this, "First Name is required!");
        }else if(txtMName.getText().isEmpty()){
            JOptionPane.showMessageDialog(this, "Middle Name is required!");
        }else if(txtLName.getText().isEmpty()){
            JOptionPane.showMessageDialog(this, "Last Name is required!");
        }else if(txtAddress.getText().isEmpty()){
            JOptionPane.showMessageDialog(this, "Address is required!");
        }else if(txtEmail.getText().isEmpty()){
            JOptionPane.showMessageDialog(this, "Email is required!!");
        }else{
        try {
            // TODO add your handling code here:
            String FName = txtFName.getText();
            String MName = txtMName.getText();
            String LName = txtLName.getText();
            String Address = txtAddress.getText();
            String Email = txtEmail.getText();
            String UID = comboSearch.getSelectedItem().toString();
        
            pst = con.prepareStatement("UPDATE user_info SET FName=?,MName=?,LName=?,Address=?,Email=? WHERE id=?");
            
            pst.setString(1, FName);
            pst.setString(2, MName);
            pst.setString(3, LName);
            pst.setString(4, Address);
            pst.setString(5, Email);
            pst.setString(6, UID);
            
            int k = pst.executeUpdate();
            
            if(k==1){
                JOptionPane.showMessageDialog(this,"Record Successfully UPDATED");
                txtFName.setText("");
                txtMName.setText("");
                txtLName.setText("");
                txtAddress.setText("");
                txtEmail.setText("");
                txtFName.requestFocus();
                LoadUserNO();
                Fetch();
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(User_Information.class.getName()).log(Level.SEVERE, null, ex);
        }
        }  
    }//GEN-LAST:event_btnUPDATEActionPerformed

    private void btnADDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnADDActionPerformed
        if(txtFName.getText().isEmpty()){
            JOptionPane.showMessageDialog(this, "First Name is required!");
        }else if(txtMName.getText().isEmpty()){
            JOptionPane.showMessageDialog(this, "Middle Name is required!");
        }else if(txtLName.getText().isEmpty()){
            JOptionPane.showMessageDialog(this, "Last Name is required!");
        }else if(txtAddress.getText().isEmpty()){
            JOptionPane.showMessageDialog(this, "Address is required!");
        }else if(txtEmail.getText().isEmpty()){
            JOptionPane.showMessageDialog(this, "Email is required!!");
        }else{
        
        try {
            // TODO add your handling code here:
            String FName = txtFName.getText();
            String MName = txtMName.getText();
            String LName = txtLName.getText();
            String Address = txtAddress.getText();
            String Email = txtEmail.getText();
            
            pst = con.prepareStatement("INSERT INTO user_info (FName,MName,LName,Address,Email)Values(?,?,?,?,?)");
            pst.setString(1,FName);
            pst.setString(2,MName);
            pst.setString(3,LName);
            pst.setString(4,Address);
            pst.setString(5,Email);
            
            int k = pst.executeUpdate();
            
            if(k==1){
                JOptionPane.showMessageDialog(this,"Record Added Successfully!");
                txtFName.setText("");
                txtMName.setText("");
                txtLName.setText("");
                txtAddress.setText("");
                txtEmail.setText("");
                txtFName.requestFocus();
                LoadUserNO();
                Fetch();
            }else{
                JOptionPane.showMessageDialog(this,"Record FAILED To Save!!!");
            }
        } catch (SQLException ex) {
            Logger.getLogger(User_Information.class.getName()).log(Level.SEVERE, null, ex);
        }
        }
    }//GEN-LAST:event_btnADDActionPerformed

    private void btnSEARCHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSEARCHActionPerformed
        try {
            // TODO add your handling code here:
            String UID = comboSearch.getSelectedItem().toString();
            
            pst = con.prepareStatement("SELECT * FROM user_info WHERE id=?");
            pst.setString(1, UID);
            
            if(rs.next()==true){
                txtFName.setText(rs.getString(2));
                txtMName.setText(rs.getString(3));
                txtLName.setText(rs.getString(4));
                txtAddress.setText(rs.getString(5));
                txtEmail.setText(rs.getString(6));
            }else{
                JOptionPane.showMessageDialog(this,"No RECORD Found!!");
            }
            rs = pst.executeQuery();
        } catch (SQLException ex) {
            Logger.getLogger(User_Information.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }//GEN-LAST:event_btnSEARCHActionPerformed

    private void btnDELETEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDELETEActionPerformed
        try {
            // TODO add your handling code here:
            String UID = comboSearch.getSelectedItem().toString();
            pst = con.prepareStatement("DELETE FROM user_info WHERE id=?");
            pst.setString(1,UID);
            
            int k = pst.executeUpdate();
            
            if(k==1){
                JOptionPane.showMessageDialog(this,"Record Has Been DELETED Successfully!!");
                txtFName.setText("");
                txtMName.setText("");
                txtLName.setText("");
                txtAddress.setText("");
                txtEmail.setText("");
                txtFName.requestFocus();
                LoadUserNO();
                Fetch();
            }else{
                JOptionPane.showMessageDialog(this,"Record FAILED to DELETE!!!");
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(User_Information.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnDELETEActionPerformed

    private void btnEXPORTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEXPORTActionPerformed
        // TODO add your handling code here:
        String filename;
        filename = "C:\\Users\\Matsura-Noimy\\ExportedFileJava.csv";
        
        try {
            try (FileWriter fw = new FileWriter(filename)) {
                pst = con.prepareStatement("SELECT * FROM User_info");
                rs = pst.executeQuery();
                
                while(rs.next()) {
                    fw.append(rs.getString(1));
                    fw.append(',');
                    fw.append(rs.getString(2));
                    fw.append(',');
                    fw.append(rs.getString(3));
                    fw.append(',');
                    fw.append(rs.getString(4));
                    fw.append(',');
                    fw.append(rs.getString(5));
                    fw.append(',');
                    fw.append(rs.getString(6));
                    fw.append('\n');
                }
                JOptionPane.showMessageDialog(this, "Successfully Exported To CSV!!");
                fw.flush();
                fw.close();
            }
        } catch (IOException ex) {
            Logger.getLogger(User_Information.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(User_Information.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnEXPORTActionPerformed

    private void btnPDFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPDFActionPerformed
        try {
            // TODO add your handling code here:
            
            pst = con.prepareStatement("SELECT * FROM user_info");
            rs = pst.executeQuery();
            
            Document PDFreport = new Document();
            PdfWriter.getInstance(PDFreport, new FileOutputStream("E:\\OutputReportJava.pdf"));
            
            PDFreport.open();
            
            PdfPTable PDFTable = new PdfPTable(6); 
            PdfPCell table_cell;
            
            while(rs.next()){
                
                String UID = rs.getString("id");
                table_cell = new PdfPCell(new Phrase(UID));
                PDFTable.addCell(table_cell);
                
                String FFName = rs.getString("FName");
                table_cell = new PdfPCell(new Phrase(FFName));
                PDFTable.addCell(table_cell);
                
                String MMName = rs.getString("MName");
                table_cell = new PdfPCell(new Phrase(MMName));
                PDFTable.addCell(table_cell);
                
                String LLName = rs.getString("LName");
                table_cell = new PdfPCell(new Phrase(LLName));
                PDFTable.addCell(table_cell);
                
                String AAddress = rs.getString("Address");
                table_cell = new PdfPCell(new Phrase(AAddress));
                PDFTable.addCell(table_cell);
                
                String EEmail = rs.getString("Email");
                table_cell = new PdfPCell(new Phrase(EEmail));
                PDFTable.addCell(table_cell);
                
            } 
            JOptionPane.showMessageDialog(this, "Successfully Exported To PDF!!");
            
            PDFreport.add(PDFTable);
            PDFreport.close();
            
        } catch (SQLException ex) {
            Logger.getLogger(User_Information.class.getName()).log(Level.SEVERE, null, ex);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(User_Information.class.getName()).log(Level.SEVERE, null, ex);
        } catch (DocumentException ex) {
            Logger.getLogger(User_Information.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }//GEN-LAST:event_btnPDFActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(User_Information.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(User_Information.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(User_Information.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(User_Information.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LogInForm().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Address;
    private javax.swing.JLabel Email;
    private javax.swing.JLabel FName;
    private javax.swing.JLabel FORM;
    private javax.swing.JLabel LName;
    private javax.swing.JLabel MName;
    private javax.swing.JLabel UserID;
    private javax.swing.JButton btnADD;
    private javax.swing.JButton btnDELETE;
    private javax.swing.JButton btnEXPORT;
    private javax.swing.JButton btnPDF;
    private javax.swing.JButton btnSEARCH;
    private javax.swing.JButton btnUPDATE;
    private javax.swing.JComboBox<String> comboSearch;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField txtAddress;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtFName;
    private javax.swing.JTextField txtLName;
    private javax.swing.JTextField txtMName;
    // End of variables declaration//GEN-END:variables
}
